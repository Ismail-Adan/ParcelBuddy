<?php
//session_start();

require_once('Models/DeliveryPointDataSet.php');


$view = new stdClass();
$view->pageTitle = 'Edit delivery point';
$view->showNavbar = $_SESSION['showNavbar'] = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delivery_id'])) {

        // Get the delivery ID to be edited
        $deliveryIdToEdited = $_POST['delivery_id'];

        $DeliveryPointDataSet = new DeliveryPointDataSet();

        //output the delivery points and specifically deliverers and statuses in the database in a dropbox
        //$view->deliverers = $DeliveryPointDataSet->fetchDeliverersForID($deliveryIdToEdited);//Uncomment
        //$view->statuses = $DeliveryPointDataSet->fetchStatusForID($deliveryIdToEdited);//Uncomment
        $view->deliverers = $DeliveryPointDataSet->fetchDeliverers();//Uncomment
        $view->statuses = $DeliveryPointDataSet->fetchStatus();//Uncomment
        $view->DeliveryPointDataSet = $DeliveryPointDataSet->fetchDeliveryPointByID($deliveryIdToEdited);
        //var_dump($view->DeliveryPointDataSet);

        if (isset($_POST['edit'])) {


            $name = $_POST['Name'] ?? '';
            $address1 = $_POST['Address1'] ?? '';
            $address2 = $_POST['Address2'] ?? '';
            $postcode = $_POST['Postcode'] ?? '';
            $deliverer = $_POST['Deliverer'] ?? 1;
            $lat = floatval($_POST['Latitude'] ?? '0');
            $lng = floatval($_POST['Longitude'] ?? '0');
            $status = $_POST['Status'] ?? 1;
            $deliveryPhoto = $_POST['DeliveryPhoto'] ?? '';

            // Edit the delivery by its ID
            var_dump($deliverer);
            $isEdited = $DeliveryPointDataSet->editDeliveryPoint($deliveryIdToEdited, $name, $address1, $address2, $postcode, $deliverer, $lat, $lng, $status, $deliveryPhoto);


            // Optionally handle the success or failure of editing
            if ($isEdited) {
                // Deletion was successful
                $view->isEdited = "Delivery Point with ID $deliveryIdToEdited has been edited successfully!";
                require_once('deliveryPoints.php');
                exit();

            } elseif (empty($isEdited)) {
                $view->isEdited = "Delivery point has not been edited.";

            }
        }

    }

}

require_once('Views/editDelivery.phtml');

